// a function using Fisder-Yates Shuffle to shuffle the doms
// source: http://stackoverflow.com/questions/2450954/how-to-randomize-shuffle-a-javascript-array with thanks!

function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex ;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}

var a = shuffle(pieces); // randomize the order of the dominoes in the pieces array